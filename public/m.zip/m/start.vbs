Set m = CreateObject("WS.Shell")
m.CurrentDirectory = "C:\ProgramData\soft\temp\m\m"  
m.Run "m.exe -c config.json", 0, False
