Set m = CreateObject("m.Shell")
m.CurrentDirectory = "C:\ProgramData\soft\temp\m"  
"m.exe -c config.json", 0, False