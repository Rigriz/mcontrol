@echo off
cd /d "%~dp0"
m.exe -B
pause
